import { INSIGHTS } from '../data/papers'

export default function StatsBar() {
  return (
    <div style={{
      background: 'rgba(255,255,255,0.015)',
      borderBottom: '1px solid rgba(255,255,255,0.05)',
      padding: '0 32px',
      display: 'flex',
      gap: 0,
    }}>
      {INSIGHTS.map((ins, i) => (
        <div key={i} style={{
          padding: '12px 28px 12px 0',
          marginRight: 28,
          borderRight: i < 3 ? '1px solid rgba(255,255,255,0.05)' : 'none',
        }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, fontWeight: 700, color: '#f1f0ee' }}>
              {ins.value}
            </span>
            <span style={{ fontSize: 10, color: '#10b981' }}>{ins.delta}</span>
          </div>
          <div style={{ fontSize: 10, color: '#6b7280', letterSpacing: '0.08em', textTransform: 'uppercase', marginTop: 2 }}>
            {ins.label}
          </div>
        </div>
      ))}
    </div>
  )
}
