import { useState, useEffect, useRef } from 'react'
import { sendChatMessage } from '../api/client'

const INIT = [
  { role: 'assistant', content: "Hello, researcher. I've analyzed your library and identified 5 emerging themes in your saved papers. What would you like to explore today?" },
]

function Spinner() {
  return (
    <span style={{
      display: 'inline-block', width: 14, height: 14,
      border: '2px solid #f59e0b55', borderTop: '2px solid #f59e0b',
      borderRadius: '50%', animation: 'spin 0.7s linear infinite', marginRight: 8,
    }} />
  )
}

export default function ChatPanel() {
  const [messages, setMessages] = useState(INIT)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function send() {
    const q = input.trim()
    if (!q || loading) return
    setInput('')
    const newMessages = [...messages, { role: 'user', content: q }]
    setMessages(newMessages)
    setLoading(true)
    try {
      const reply = await sendChatMessage(newMessages)
      setMessages(prev => [...prev, { role: 'assistant', content: reply }])
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Connection error. Please try again.' }])
    }
    setLoading(false)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ fontSize: 10, letterSpacing: '0.15em', color: '#f59e0b', textTransform: 'uppercase', fontWeight: 700, marginBottom: 14 }}>
        ✦ Research Intelligence Chat
      </div>

      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 12, paddingRight: 4, marginBottom: 14 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: m.role === 'user' ? 'row-reverse' : 'row', gap: 10, alignItems: 'flex-start' }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 11, fontWeight: 700,
              background: m.role === 'assistant' ? 'linear-gradient(135deg, #f59e0b, #d97706)' : 'rgba(255,255,255,0.08)',
              color: m.role === 'assistant' ? '#0f0e0c' : '#9ca3af',
              border: m.role === 'user' ? '1px solid rgba(255,255,255,0.1)' : 'none',
            }}>
              {m.role === 'assistant' ? '✦' : 'R'}
            </div>
            <div style={{
              maxWidth: '78%', padding: '10px 14px',
              borderRadius: m.role === 'assistant' ? '4px 14px 14px 14px' : '14px 4px 14px 14px',
              background: m.role === 'assistant' ? 'rgba(245,158,11,0.07)' : 'rgba(255,255,255,0.05)',
              border: m.role === 'assistant' ? '1px solid rgba(245,158,11,0.15)' : '1px solid rgba(255,255,255,0.07)',
              fontSize: 13, color: '#d1d5db', lineHeight: 1.65,
            }}>
              {m.content}
            </div>
          </div>
        ))}

        {loading && (
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%',
              background: 'linear-gradient(135deg, #f59e0b, #d97706)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 11, fontWeight: 700, color: '#0f0e0c',
            }}>✦</div>
            <div style={{
              padding: '12px 16px', borderRadius: '4px 14px 14px 14px',
              background: 'rgba(245,158,11,0.07)', border: '1px solid rgba(245,158,11,0.15)',
              display: 'flex', alignItems: 'center',
            }}>
              <Spinner /><span style={{ fontSize: 12, color: '#9ca3af' }}>Analyzing...</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          placeholder="Ask about research gaps, methodologies, trends..."
          style={{
            flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)',
            borderRadius: 10, padding: '11px 15px', color: '#d1d5db', fontSize: 13,
            outline: 'none', fontFamily: 'inherit',
          }}
        />
        <button
          onClick={send}
          disabled={loading || !input.trim()}
          style={{
            background: input.trim() && !loading ? 'linear-gradient(135deg, #f59e0b, #d97706)' : 'rgba(255,255,255,0.05)',
            border: 'none', borderRadius: 10, padding: '0 18px',
            color: input.trim() && !loading ? '#0f0e0c' : '#4b5563',
            fontWeight: 700, fontSize: 13, cursor: 'pointer', transition: 'all 0.2s',
          }}
        >→</button>
      </div>
    </div>
  )
}
