import { useState } from 'react'
import { discoverPapers } from '../api/client'

function Spinner() {
  return (
    <span style={{
      display: 'inline-block', width: 14, height: 14,
      border: '2px solid #f59e0b55', borderTop: '2px solid #f59e0b',
      borderRadius: '50%', animation: 'spin 0.7s linear infinite', marginRight: 8,
    }} />
  )
}

export default function DiscoverTab() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  async function runSearch() {
    if (!query.trim()) return
    setLoading(true)
    setError(null)
    setResults(null)
    try {
      const papers = await discoverPapers(query)
      setResults(papers)
    } catch {
      setError('Discovery failed. Please try again.')
      setResults([])
    }
    setLoading(false)
  }

  return (
    <>
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, color: '#f1f0ee', marginBottom: 4 }}>
          AI-Powered Discovery
        </div>
        <div style={{ fontSize: 13, color: '#6b7280' }}>
          Describe your research interest and let the agent find relevant papers.
        </div>
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && runSearch()}
          placeholder="e.g. sparse attention for long sequences..."
          style={{
            flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 10, padding: '11px 15px', color: '#d1d5db', fontSize: 13,
            outline: 'none', fontFamily: 'inherit',
          }}
        />
        <button
          onClick={runSearch}
          disabled={loading}
          style={{
            background: 'linear-gradient(135deg, #f59e0b, #d97706)', border: 'none',
            borderRadius: 10, padding: '0 20px', color: '#0f0e0c',
            fontWeight: 700, fontSize: 13, cursor: loading ? 'not-allowed' : 'pointer',
            display: 'flex', alignItems: 'center', opacity: loading ? 0.7 : 1,
          }}
        >
          {loading && <Spinner />}
          {loading ? 'Finding...' : 'Discover'}
        </button>
      </div>

      <div style={{ overflowY: 'auto', flex: 1 }}>
        {error && <div style={{ color: '#ef4444', fontSize: 13, marginBottom: 12 }}>{error}</div>}

        {results === null && !loading && (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontSize: 40, marginBottom: 14 }}>✦</div>
            <div style={{ fontSize: 14, color: '#6b7280', lineHeight: 1.7 }}>
              Enter a research topic above and the<br />AI agent will surface relevant papers.
            </div>
          </div>
        )}

        {results?.map((p, i) => (
          <div key={i} style={{
            background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: 14, padding: '16px 18px', marginBottom: 12,
            animation: 'fadeIn 0.3s ease',
          }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 15, color: '#f1f0ee', fontWeight: 700, marginBottom: 5 }}>
              {p.title}
            </div>
            <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 8 }}>
              {p.authors} · {p.year} · <span style={{ color: '#f59e0b88' }}>{p.journal}</span>
            </div>
            <div style={{ fontSize: 13, color: '#6b7280', lineHeight: 1.6, marginBottom: 10 }}>{p.teaser}</div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {p.tags?.map(t => (
                <span key={t} style={{
                  fontSize: 10, background: 'rgba(245,158,11,0.1)', color: '#f59e0b',
                  border: '1px solid rgba(245,158,11,0.2)', borderRadius: 20,
                  padding: '2px 9px', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600,
                }}>{t}</span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
