import { useState } from 'react'
import { summarizePaper } from '../api/client'

function Spinner() {
  return (
    <span style={{
      display: 'inline-block', width: 14, height: 14,
      border: '2px solid #f59e0b55', borderTop: '2px solid #f59e0b',
      borderRadius: '50%', animation: 'spin 0.7s linear infinite', marginRight: 8,
    }} />
  )
}

export default function DetailPanel({ paper, onClose }) {
  const [loading, setLoading] = useState(false)
  const [summary, setSummary] = useState(null)
  const [error, setError] = useState(null)

  async function generateSummary() {
    setLoading(true)
    setSummary(null)
    setError(null)
    try {
      const text = await summarizePaper({
        title: paper.title,
        authors: paper.authors,
        abstract: paper.abstract,
      })
      setSummary(text)
    } catch (err) {
      setError('Error generating summary. Please try again.')
    }
    setLoading(false)
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.15em', color: '#f59e0b', textTransform: 'uppercase', fontWeight: 700, marginBottom: 6 }}>
            Selected Paper
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, color: '#f1f0ee', margin: 0, lineHeight: 1.3, maxWidth: 360 }}>
            {paper.title}
          </h2>
        </div>
        <button
          onClick={onClose}
          style={{
            background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)',
            color: '#9ca3af', borderRadius: 8, padding: '6px 12px', cursor: 'pointer', fontSize: 12,
          }}
        >
          ✕ Close
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 18 }}>
        {[['Authors', paper.authors], ['Year', paper.year], ['Journal', paper.journal], ['Citations', `${(paper.citations / 1000).toFixed(1)}k`]].map(([k, v]) => (
          <div key={k} style={{
            background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: 10, padding: '10px 14px',
          }}>
            <div style={{ fontSize: 10, color: '#6b7280', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 3 }}>{k}</div>
            <div style={{ fontSize: 13, color: '#d1d5db', fontWeight: 600 }}>{v}</div>
          </div>
        ))}
      </div>

      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 11, color: '#6b7280', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>Abstract</div>
        <p style={{ fontSize: 13, color: '#9ca3af', lineHeight: 1.7, margin: 0 }}>{paper.abstract}</p>
      </div>

      <button
        onClick={generateSummary}
        disabled={loading}
        style={{
          background: loading ? 'rgba(245,158,11,0.1)' : 'linear-gradient(135deg, #f59e0b, #d97706)',
          border: 'none', borderRadius: 10, padding: '12px 20px',
          color: loading ? '#f59e0b' : '#0f0e0c',
          fontWeight: 700, fontSize: 13, cursor: loading ? 'not-allowed' : 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          letterSpacing: '0.04em', marginBottom: 16, transition: 'all 0.2s',
        }}
      >
        {loading && <Spinner />}
        {loading ? 'Analyzing Paper...' : '✦ Generate AI Summary'}
      </button>

      {error && (
        <div style={{ color: '#ef4444', fontSize: 13, marginBottom: 12 }}>{error}</div>
      )}

      {summary && (
        <div style={{
          background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.2)',
          borderRadius: 12, padding: '16px 18px', flex: 1, overflowY: 'auto',
        }}>
          <div style={{ fontSize: 10, color: '#f59e0b', letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 10 }}>
            ✦ AI Research Summary
          </div>
          <p style={{ fontSize: 13, color: '#d1d5db', lineHeight: 1.75, margin: 0, whiteSpace: 'pre-wrap' }}>{summary}</p>
        </div>
      )}
    </div>
  )
}
