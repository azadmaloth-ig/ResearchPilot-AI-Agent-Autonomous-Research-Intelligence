import { useState } from 'react'

export default function PaperCard({ paper, onSelect, selected }) {
  const [saved, setSaved] = useState(paper.saved)

  return (
    <div
      onClick={() => onSelect(paper)}
      style={{
        background: selected ? 'rgba(245,158,11,0.07)' : 'rgba(255,255,255,0.025)',
        border: selected ? '1px solid rgba(245,158,11,0.45)' : '1px solid rgba(255,255,255,0.06)',
        borderRadius: 14,
        padding: '18px 20px',
        cursor: 'pointer',
        transition: 'all 0.22s',
        marginBottom: 12,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Relevance bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0,
        width: `${paper.relevance}%`, height: 2,
        background: 'linear-gradient(90deg, #f59e0b, #ef4444)',
        borderRadius: 2,
      }} />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontSize: 15, fontWeight: 700, color: '#f1f0ee', lineHeight: 1.4, marginBottom: 5,
          }}>
            {paper.title}
          </div>
          <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 8 }}>
            {paper.authors} · {paper.year} · <span style={{ color: '#f59e0b88' }}>{paper.journal}</span>
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {paper.tags.map(t => (
              <span key={t} style={{
                fontSize: 10, fontWeight: 600, letterSpacing: '0.06em',
                background: 'rgba(245,158,11,0.1)', color: '#f59e0b',
                border: '1px solid rgba(245,158,11,0.2)', borderRadius: 20,
                padding: '2px 9px', textTransform: 'uppercase',
              }}>{t}</span>
            ))}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
          <button
            onClick={e => { e.stopPropagation(); setSaved(s => !s) }}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              fontSize: 16, color: saved ? '#f59e0b' : '#4b5563',
              transition: 'color 0.2s', padding: 2,
            }}
          >
            {saved ? '★' : '☆'}
          </button>
          <div style={{ fontSize: 10, color: '#6b7280', textAlign: 'right' }}>
            <span style={{ display: 'block', color: '#d1d5db', fontWeight: 700, fontSize: 13 }}>
              {paper.relevance}%
            </span>
            <span>relevance</span>
          </div>
          <div style={{ fontSize: 10, color: '#6b7280' }}>
            {(paper.citations / 1000).toFixed(1)}k cited
          </div>
        </div>
      </div>
    </div>
  )
}
