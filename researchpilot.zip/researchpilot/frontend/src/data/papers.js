export const PAPERS = [
  {
    id: 1,
    title: "Attention Is All You Need",
    authors: "Vaswani et al.",
    year: 2017,
    journal: "NeurIPS",
    tags: ["Transformers", "NLP", "Deep Learning"],
    citations: 98421,
    abstract:
      "We propose a new simple network architecture, the Transformer, based solely on attention mechanisms, dispensing with recurrence and convolutions entirely.",
    saved: true,
    relevance: 98,
  },
  {
    id: 2,
    title: "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding",
    authors: "Devlin et al.",
    year: 2019,
    journal: "NAACL",
    tags: ["BERT", "NLP", "Pre-training"],
    citations: 72310,
    abstract:
      "We introduce BERT, which stands for Bidirectional Encoder Representations from Transformers, designed to pre-train deep bidirectional representations.",
    saved: false,
    relevance: 94,
  },
  {
    id: 3,
    title: "Scaling Laws for Neural Language Models",
    authors: "Kaplan et al.",
    year: 2020,
    journal: "arXiv",
    tags: ["Scaling", "LLM", "Empirical Study"],
    citations: 5821,
    abstract:
      "We study empirical scaling laws for language model performance on the cross-entropy loss, finding smooth power laws with model size, dataset size, and compute.",
    saved: true,
    relevance: 89,
  },
  {
    id: 4,
    title: "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks",
    authors: "Lewis et al.",
    year: 2021,
    journal: "NeurIPS",
    tags: ["RAG", "Retrieval", "Generation"],
    citations: 11203,
    abstract:
      "We explore a general-purpose fine-tuning recipe for RAG — models which combine pre-trained parametric and non-parametric memory for language generation.",
    saved: false,
    relevance: 92,
  },
  {
    id: 5,
    title: "Chain-of-Thought Prompting Elicits Reasoning in Large Language Models",
    authors: "Wei et al.",
    year: 2022,
    journal: "NeurIPS",
    tags: ["CoT", "Reasoning", "Prompting"],
    citations: 9847,
    abstract:
      "We explore how generating a chain of thought — a series of intermediate reasoning steps — significantly improves the ability of LLMs to perform complex reasoning.",
    saved: false,
    relevance: 87,
  },
]

export const TAGS_ALL = ["All", "NLP", "LLM", "Transformers", "RAG", "Reasoning", "Scaling", "BERT", "Deep Learning"]

export const INSIGHTS = [
  { label: "Papers Analyzed", value: "2,847", delta: "+124 this week" },
  { label: "Topics Mapped",   value: "63",    delta: "+8 new clusters" },
  { label: "Avg Relevance",   value: "91.2%", delta: "+3.1% vs last month" },
  { label: "Hours Saved",     value: "184h",  delta: "est. researcher time" },
]
