const BASE = '/api'

export async function summarizePaper({ title, authors, abstract }) {
  const res = await fetch(`${BASE}/summarize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, authors, abstract }),
  })
  if (!res.ok) throw new Error('Summary request failed')
  const data = await res.json()
  return data.summary
}

export async function discoverPapers(query) {
  const res = await fetch(`${BASE}/discover`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  })
  if (!res.ok) throw new Error('Discovery request failed')
  const data = await res.json()
  return data.papers
}

export async function sendChatMessage(messages) {
  const res = await fetch(`${BASE}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages }),
  })
  if (!res.ok) throw new Error('Chat request failed')
  const data = await res.json()
  return data.response
}
