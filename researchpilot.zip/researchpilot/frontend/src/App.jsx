import { useState } from 'react'
import StatsBar from './components/StatsBar'
import PaperCard from './components/PaperCard'
import DetailPanel from './components/DetailPanel'
import ChatPanel from './components/ChatPanel'
import DiscoverTab from './components/DiscoverTab'
import { PAPERS, TAGS_ALL } from './data/papers'

const GLOBAL_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;800&family=DM+Sans:wght@300;400;500;600;700&display=swap');
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
  input::placeholder { color: #4b5563; }
`

export default function App() {
  const [activeTab, setActiveTab] = useState('library')
  const [searchQuery, setSearchQuery] = useState('')
  const [activeTag, setActiveTag] = useState('All')
  const [selectedPaper, setSelectedPaper] = useState(null)

  const filtered = PAPERS.filter(p => {
    const matchTag = activeTag === 'All' || p.tags.includes(activeTag)
    const matchSearch =
      !searchQuery ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.authors.toLowerCase().includes(searchQuery.toLowerCase())
    return matchTag && matchSearch
  })

  return (
    <div style={{ minHeight: '100vh', background: '#0b0a09', fontFamily: "'DM Sans', 'Segoe UI', sans-serif", color: '#d1d5db', display: 'flex', flexDirection: 'column' }}>
      <style>{GLOBAL_STYLES}</style>

      {/* Header */}
      <header style={{
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        padding: '0 32px', display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', height: 62, flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10,
            background: 'linear-gradient(135deg, #f59e0b, #b45309)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16,
          }}>✦</div>
          <div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 800, fontSize: 17, color: '#f1f0ee', letterSpacing: '-0.01em' }}>
              ResearchPilot
            </div>
            <div style={{ fontSize: 10, color: '#6b7280', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              Autonomous Research Intelligence
            </div>
          </div>
        </div>

        <nav style={{ display: 'flex', gap: 4 }}>
          {[['library', 'Library'], ['discover', 'Discover'], ['chat', 'AI Assistant']].map(([k, label]) => (
            <button
              key={k}
              onClick={() => setActiveTab(k)}
              style={{
                background: activeTab === k ? 'rgba(245,158,11,0.1)' : 'none',
                border: activeTab === k ? '1px solid rgba(245,158,11,0.25)' : '1px solid transparent',
                color: activeTab === k ? '#f59e0b' : '#6b7280',
                borderRadius: 8, padding: '6px 16px', cursor: 'pointer',
                fontSize: 13, fontWeight: 500, transition: 'all 0.2s',
              }}
            >
              {label}
            </button>
          ))}
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#10b981', boxShadow: '0 0 6px #10b981' }} />
          <span style={{ fontSize: 12, color: '#6b7280' }}>Agent Active</span>
        </div>
      </header>

      <StatsBar />

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden', padding: 24, gap: 20 }}>

        {/* Library Tab */}
        {activeTab === 'library' && (
          <div style={{ width: selectedPaper ? 420 : '100%', flexShrink: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden', animation: 'fadeIn 0.3s ease' }}>
            <div style={{ marginBottom: 16, display: 'flex', gap: 10 }}>
              <input
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search your library..."
                style={{
                  flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: 10, padding: '10px 15px', color: '#d1d5db', fontSize: 13,
                  outline: 'none', fontFamily: 'inherit',
                }}
              />
            </div>
            <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' }}>
              {TAGS_ALL.map(t => (
                <button
                  key={t}
                  onClick={() => setActiveTag(t)}
                  style={{
                    background: activeTag === t ? 'rgba(245,158,11,0.15)' : 'rgba(255,255,255,0.03)',
                    border: activeTag === t ? '1px solid rgba(245,158,11,0.35)' : '1px solid rgba(255,255,255,0.07)',
                    color: activeTag === t ? '#f59e0b' : '#6b7280',
                    borderRadius: 20, padding: '4px 13px', fontSize: 11,
                    cursor: 'pointer', fontWeight: 500, transition: 'all 0.18s',
                  }}
                >{t}</button>
              ))}
            </div>
            <div style={{ overflowY: 'auto', flex: 1 }}>
              <div style={{ fontSize: 10, color: '#6b7280', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 12 }}>
                {filtered.length} Papers · Sorted by Relevance
              </div>
              {filtered.map(p => (
                <PaperCard key={p.id} paper={p} selected={selectedPaper?.id === p.id} onSelect={setSelectedPaper} />
              ))}
            </div>
          </div>
        )}

        {/* Discover Tab */}
        {activeTab === 'discover' && (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', animation: 'fadeIn 0.3s ease' }}>
            <DiscoverTab />
          </div>
        )}

        {/* Chat Tab */}
        {activeTab === 'chat' && (
          <div style={{
            flex: 1, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: 16, padding: 24, overflow: 'hidden', display: 'flex', flexDirection: 'column',
            animation: 'fadeIn 0.3s ease',
          }}>
            <ChatPanel />
          </div>
        )}

        {/* Detail Panel */}
        {selectedPaper && activeTab === 'library' && (
          <div style={{
            flex: 1, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: 16, padding: 24, overflow: 'hidden', display: 'flex', flexDirection: 'column',
            animation: 'fadeIn 0.3s ease',
          }}>
            <DetailPanel paper={selectedPaper} onClose={() => setSelectedPaper(null)} />
          </div>
        )}

        {/* Empty state */}
        {!selectedPaper && activeTab === 'library' && (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 14, color: '#374151' }}>
            <div style={{ fontSize: 56 }}>✦</div>
            <div style={{ fontSize: 15, color: '#4b5563', textAlign: 'center', lineHeight: 1.7 }}>
              Select a paper to explore<br />AI-powered insights and summaries
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
