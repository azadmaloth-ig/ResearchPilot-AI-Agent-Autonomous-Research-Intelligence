from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import httpx
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="ResearchPilot API",
    description="Autonomous Research Intelligence Hub — Backend API",
    version="1.0.0"
)

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_MODEL = "claude-sonnet-4-20250514"

# ---------- Models ----------

class Message(BaseModel):
    role: str
    content: str

class SummaryRequest(BaseModel):
    title: str
    authors: str
    abstract: str

class DiscoverRequest(BaseModel):
    query: str

class ChatRequest(BaseModel):
    messages: List[Message]

# ---------- Helpers ----------

async def call_claude(system: str, messages: list, max_tokens: int = 1000) -> str:
    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY not configured")
    
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            ANTHROPIC_URL,
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": CLAUDE_MODEL,
                "max_tokens": max_tokens,
                "system": system,
                "messages": messages,
            }
        )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    data = response.json()
    return data["content"][0]["text"]

# ---------- Routes ----------

@app.get("/")
def root():
    return {"status": "ok", "service": "ResearchPilot API"}

@app.get("/health")
def health():
    return {"status": "healthy", "model": CLAUDE_MODEL}


@app.post("/api/summarize")
async def summarize_paper(req: SummaryRequest):
    """Generate a structured AI summary for a given paper."""
    system = (
        "You are ResearchPilot, an expert AI research assistant. "
        "Provide concise, insightful academic summaries. Use precise language. "
        "Structure with: KEY CONTRIBUTION, METHODOLOGY, IMPACT. "
        "Keep it under 120 words total. Use plain text, no markdown symbols."
    )
    prompt = (
        f"Summarize this paper for a researcher:\n\n"
        f"Title: {req.title}\n"
        f"Authors: {req.authors}\n"
        f"Abstract: {req.abstract}"
    )
    text = await call_claude(system, [{"role": "user", "content": prompt}])
    return {"summary": text}


@app.post("/api/discover")
async def discover_papers(req: DiscoverRequest):
    """AI-powered paper discovery based on a research topic query."""
    system = (
        "You are a research discovery AI. Given a search query, generate 3 concise paper "
        "recommendations in JSON array format only. Each object: "
        "{title, authors, year, journal, tags (array of strings), relevance (number 70-99), teaser (1 sentence)}. "
        "Return ONLY valid JSON array, no other text, no markdown."
    )
    text = await call_claude(
        system,
        [{"role": "user", "content": f"Find papers about: {req.query}"}]
    )
    import json
    clean = text.replace("```json", "").replace("```", "").strip()
    papers = json.loads(clean)
    return {"papers": papers}


@app.post("/api/chat")
async def research_chat(req: ChatRequest):
    """Persistent research assistant chat endpoint."""
    system = (
        "You are ResearchPilot, an expert AI research assistant embedded in an academic "
        "research intelligence platform. Help researchers discover insights, understand papers, "
        "identify research gaps, suggest related work, and improve their research process. "
        "Be concise, precise, and insightful. Speak like a knowledgeable academic collaborator."
    )
    messages = [{"role": m.role, "content": m.content} for m in req.messages]
    text = await call_claude(system, messages)
    return {"response": text}
