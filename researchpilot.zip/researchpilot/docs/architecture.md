# ResearchPilot — Architecture

## Overview

```
Browser (React)
    │
    ├── /api/summarize  ──► FastAPI ──► Anthropic Claude
    ├── /api/discover   ──► FastAPI ──► Anthropic Claude
    └── /api/chat       ──► FastAPI ──► Anthropic Claude
```

## Frontend (React + Vite)

| Component | Responsibility |
|---|---|
| `App.jsx` | Root layout, tab routing, paper filtering |
| `StatsBar.jsx` | Displays research analytics stats |
| `PaperCard.jsx` | Individual paper tile with relevance bar |
| `DetailPanel.jsx` | Full paper view + AI summary generation |
| `DiscoverTab.jsx` | AI-powered paper discovery UI |
| `ChatPanel.jsx` | Persistent research assistant chat |
| `api/client.js` | Fetch wrappers for all backend endpoints |
| `data/papers.js` | Static seed data for demo library |

## Backend (FastAPI)

| Route | Method | Description |
|---|---|---|
| `/` | GET | Health check |
| `/health` | GET | Service status |
| `/api/summarize` | POST | Generate structured paper summary |
| `/api/discover` | POST | AI-powered paper recommendations |
| `/api/chat` | POST | Multi-turn research assistant chat |

## AI Prompts

### Summarize
Structured summary with KEY CONTRIBUTION → METHODOLOGY → IMPACT sections, under 120 words.

### Discover
Returns JSON array of 3 papers: `{title, authors, year, journal, tags[], relevance, teaser}`.

### Chat
Acts as an expert academic collaborator — gap analysis, methodology comparison, related work.

## Data Flow

1. User triggers action (summarize / discover / chat)
2. React calls `/api/*` on FastAPI backend (proxied via Vite in dev)
3. FastAPI appends `ANTHROPIC_API_KEY` and calls Claude
4. Response streamed back to React component
5. UI updates with AI-generated content
