# ✦ ResearchPilot — Autonomous Research Intelligence Hub

> AI-powered academic research assistant for discovering, organizing, and interacting with papers.

![ResearchPilot](https://img.shields.io/badge/AI-Powered-f59e0b?style=flat-square) ![FastAPI](https://img.shields.io/badge/FastAPI-0.110-009688?style=flat-square&logo=fastapi) ![React](https://img.shields.io/badge/React-18-61dafb?style=flat-square&logo=react) ![Claude](https://img.shields.io/badge/Claude-Sonnet-blueviolet?style=flat-square)

---

## Features

- **Library** — Browse, filter, and search your paper collection with tag-based navigation
- **AI Summaries** — One-click structured summaries (Contribution → Methodology → Impact) via Claude
- **Discover** — Semantic paper discovery powered by AI recommendations
- **Research Chat** — Persistent AI assistant for research questions, gap analysis, and insights
- **FastAPI Backend** — Proxy API for secure Anthropic key management

---

## Project Structure

```
researchpilot/
├── frontend/               # React application
│   ├── src/
│   │   ├── App.jsx         # Root component
│   │   ├── main.jsx        # Entry point
│   │   ├── components/
│   │   │   ├── PaperCard.jsx
│   │   │   ├── DetailPanel.jsx
│   │   │   ├── ChatPanel.jsx
│   │   │   ├── DiscoverTab.jsx
│   │   │   └── StatsBar.jsx
│   │   ├── data/
│   │   │   └── papers.js   # Sample paper data
│   │   └── api/
│   │       └── client.js   # API client
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── backend/                # FastAPI server
│   ├── main.py             # API routes
│   ├── requirements.txt
│   └── .env.example
├── docs/
│   └── architecture.md
├── .gitignore
└── README.md
```

---

## Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/researchpilot.git
cd researchpilot
```

### 2. Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Add your ANTHROPIC_API_KEY to .env

uvicorn main:app --reload --port 8000
```

### 3. Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:5173`

---

## Environment Variables

| Variable | Description |
|---|---|
| `ANTHROPIC_API_KEY` | Your Anthropic API key (get one at console.anthropic.com) |
| `ALLOWED_ORIGINS` | CORS origins, e.g. `http://localhost:5173` |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, CSS-in-JS |
| Backend | Python, FastAPI, Uvicorn |
| AI | Anthropic Claude (claude-sonnet-4-20250514) |
| Fonts | Google Fonts (Playfair Display, DM Sans) |

---

## License

MIT
